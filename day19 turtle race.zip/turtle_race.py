import turtle as t
import random

all_turtles = []
y_cordinates = [-100,-60,-20,20,60,100]
is_race_on = False

s = t.Screen()
s.setup( width = 500 , height = 400)

user_bet = s.textinput(title="Make your Bet",prompt="Which turtle will win the race? Enter a color:")
colors = ["red","green","blue","yellow","orange","purple"]

for i in range(6):
    tim = t.Turtle(shape="turtle")
    tim.color(colors[i])
    tim.penup()
    tim.goto(-230,y_cordinates[i])
    all_turtles.append(tim)

if user_bet:
    is_race_on = True
winner = ""
while is_race_on:
    
    for turtle in all_turtles:
        rand_distance = random.randint(0,10)
        turtle.forward(rand_distance)
        if turtle.xcor() >= 230 :
            is_race_on = False
            winner = turtle.pencolor()
            if winner == user_bet:
                print(f"You've won! The {winner} turtle is the winner.")
            else:
                print(f"You've lost! The {winner} turtle is the winner.")


s.exitonclick()