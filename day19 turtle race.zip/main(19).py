import turtle as t


tim = t.Turtle()
s = t.Screen()

def move_forward():
    tim.forward(10)

def move_backward():
    tim.backward(10)

def move_clockwise():
    tim.right(30)

def move_anticlockwise():
    tim.left(30)

def clear():
    tim.clear()

s.listen()
s.onkey(move_forward,"w")
s.onkey(move_backward,"s")
s.onkey(move_clockwise,"d")
s.onkey(move_anticlockwise,"a")
s.onkey(clear,"c")

s.exitonclick()